<?php

/**
 * @file views-view-unformatted--stargrace-view.tpl.php
 * stargrace's custom view unformatted template for all views tagged with "stargrace Views".
 *
 * @ingroup views_templates
 */
?>

<?php foreach ($rows as $id => $row): ?>
  <?php print $row; ?>
<?php endforeach; ?>
<?php

/**
 * @file views-view-unformatted--rendezvous-view.tpl.php
 * rendezvous's custom view unformatted template for all views tagged with "rendezvous Views".
 *
 * @ingroup views_templates
 */
?>

<?php foreach ($rows as $id => $row): ?>
  <?php print $row; ?>
<?php endforeach; ?>
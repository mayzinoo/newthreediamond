<?php
/**
 * @file
 * Template for the menu toggle.
 */
?>
<a id="toggle-icon" class="toggle responsive-menu-toggle-icon" title="Menu" href="#off-canvas">
  <span class="icon"></span><span class="label"><?php print t('Menu'); ?></span>
</a>
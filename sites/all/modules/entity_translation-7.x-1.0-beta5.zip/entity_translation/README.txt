
-- SUMMARY --

Allows entities to be translated into different languages.

For a full description of the module, visit the project page:
  http://drupal.org/project/entity_translation
To submit bug reports and feature suggestions, or to track changes:
  http://drupal.org/project/issues/entity_translation


-- REQUIREMENTS --

None.


-- INSTALLATION --

* Install as usual, see http://drupal.org/node/70151 for further information.


-- CONFIGURATION --

* @todo


-- USAGE --

* @todo


-- CONTACT --

Current maintainers:
* Francesco Placella (plach) - http://drupal.org/user/183211
* Daniel F. Kudwien (sun) - http://drupal.org/user/54136

